
function login() {

    var email = document.getElementById("email");
    var password = document.getElementById("password");

    console.log(email, password);

    if (email === "tarun.lahrod@avizva.com" && password === "tarun") {
        window.alert("Welcome!");
    } else {
        window.alert("Invalid credentials, retry!");
    }
}
