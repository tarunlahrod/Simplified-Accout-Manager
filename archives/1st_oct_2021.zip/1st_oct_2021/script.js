
var email = document.getElementById("email");
var password = document.getElementById('password');

function login() {
    if (email === "tarun@lahrod" && password === "tarun")
    alert("Logged In");
}

var li_asset = document.getElementById("li_asset");
var li_libility = document.getElementById("li_libility");
var li_equity = document.getElementById("li_equity");
var li_income = document.getElementById("li_income");
var li_expense = document.getElementById("li_expense");

li_asset.onmouseover = function() {
    document.getElementById("account_image").src = "./images/img1.jpeg";
}
li_libility.onmouseover = function() {
    document.getElementById("account_image").src = "./images/img2.jpeg";
}
li_equity.onmouseover = function() {
    document.getElementById("account_image").src = "./images/img3.jpeg";
}
li_income.onmouseover = function() {
    document.getElementById("account_image").src = "./images/img4.jpeg";
}
li_expense.onmouseover = function() {
    document.getElementById("account_image").src = "./images/img5.jpeg";
}

// Adding Date and Time to footer
setInterval(function() {
    let curDate = new Date();
    let hh = curDate.getHours().toString().padStart(2, 0);
    let mm = curDate.getMinutes().toString().padStart(2, 0);
    let ss = curDate.getSeconds().toString().padStart(2, 0);
    let DD = curDate.getDate().toString().padStart(2, 0);
    let MM = (curDate.getMonth() + 1).toString().padStart(2, 0);
    let YYYY = curDate.getFullYear().toString();
    var dateAndTime = `Time: ${hh}:${mm}:${ss} <br> Date: ${DD}/${MM}/${YYYY}`;
    document.getElementById("footerDateTime").innerHTML = dateAndTime;
}, 1000);

